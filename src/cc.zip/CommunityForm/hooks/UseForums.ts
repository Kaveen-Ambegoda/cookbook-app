"use client";

import { useState, useEffect, useCallback } from 'react';
import { Forum, ForumFilters, Comment, Reply, CreateForumData } from '../types/index';

// Initial sample data
const sampleForums: Forum[] = [
  {
    id: '1',
    title: "What's your go-to weeknight dinner recipe? Share your quick and easy meals!",
    image: '/image/pizza.jpg', // Updated to match your public folder structure
    url: 'www.websiteaddress.com',
    timestamp: '3 hours ago',
    comments: 14,
    views: 13843,
    upvotes: 52,
    downvotes: 18,
    author: 'JohnDoe',
    category: 'Dinner',
    isFavorite: false
  },
  {
    id: '2',
    title: "Have you tried any new ingredients or spices recently? How did they change your dish?",
    image: '/image/salad.jpg', // Updated to match your public folder structure
    url: 'www.websiteaddress.com',
    timestamp: '3 hours ago',
    comments: 14,
    views: 13843,
    upvotes: 28,
    downvotes: 9,
    author: 'JaneSmith',
    category: 'Ingredients',
    isFavorite: false
  },
  {
    id: '3',
    title: "What are your favorite vegetarian recipes? Let's create a list of delicious meat-free meals.",
    image: '/image/pizza.jpg', // Updated to match your public folder structure
    url: 'www.websiteaddress.com',
    timestamp: '3 hours ago',
    comments: 14,
    views: 13843,
    upvotes: 52,
    downvotes: 18,
    author: 'VeggieKing',
    category: 'Vegetarian',
    isFavorite: false
  },
  {
    id: '4',
    title: "Baking tips and tricks: How do you get your cakes perfectly moist?",
    image: '/image/cake.jpg', // Updated to match your public folder structure
    url: 'www.websiteaddress.com',
    timestamp: '3 hours ago',
    comments: 14,
    views: 13843,
    upvotes: 52,
    downvotes: 18,
    author: 'BakingQueen',
    category: 'Baking',
    isFavorite: false
  },
  {
    id: '5',
    title: "Share your holiday cooking traditions! What special dishes do you make for the holidays?",
    image: '/image/pizza.jpg', // Updated to match your public folder structure
    url: 'www.websiteaddress.com',
    timestamp: '3 hours ago',
    comments: 14,
    views: 13843,
    upvotes: 52,
    downvotes: 18,
    author: 'HolidayChef',
    category: 'Holidays',
    isFavorite: false
  }
];

// Initial comments sample
const sampleComments: Record<string, Comment[]> = {
  '1': [
    {
      id: '101',
      forumId: '1',
      userId: 'user1',
      username: 'CookingExpert',
      content: 'I absolutely love making a quick stir-fry on weeknights. Just throw in whatever veggies and protein you have, add some soy sauce and spices, and dinner is ready in 15 minutes!',
      timestamp: '2 hours ago',
      replies: [
        {
          id: '101-1',
          commentId: '101',
          userId: 'user2',
          username: 'NoviceChef',
          content: 'What spices do you recommend for a chicken stir-fry?',
          timestamp: '1 hour ago'
        }
      ]
    }
  ]
};

interface UseForumsProps {
  currentUserId: string;
}

const useForums = ({ currentUserId }: UseForumsProps) => {
  // State for forums
  const [forums, setForums] = useState<Forum[]>(sampleForums);
  const [filteredForums, setFilteredForums] = useState<Forum[]>(sampleForums);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  
  // State for comments
  const [comments, setComments] = useState<Record<string, Comment[]>>(sampleComments);
  
  // State for filters - Changed initial category to 'All' to show all forums initially
  const [filters, setFilters] = useState<ForumFilters>({
    searchQuery: '',
    author: 'All',
    category: 'All',
    showFavorites: false,
    showMyForums: false
  });
  
  // State for active elements
  const [activeCommentId, setActiveCommentId] = useState<string | null>(null);
  
  // Get unique authors and categories for filters
  const authors = ['All', ...Array.from(new Set(forums.map(forum => forum.author)))];
  const categories = ['All', 'Snacks', 'Dinner', 'Breakfast', 'Desserts', 'Baking', 'Vegetarian', 'Holidays', 'Ingredients'];
  
  // Apply filters whenever dependencies change
  useEffect(() => {
    let result = [...forums];
    
    // Apply search filter
    if (filters.searchQuery) {
      result = result.filter(forum => 
        forum.title.toLowerCase().includes(filters.searchQuery.toLowerCase())
      );
    }
    
    // Apply author filter
    if (filters.author !== 'All') {
      result = result.filter(forum => forum.author === filters.author);
    }
    
    // Apply category filter
    if (filters.category !== 'All') {
      result = result.filter(forum => forum.category === filters.category);
    }
    
    // Apply favorites filter
    if (filters.showFavorites) {
      result = result.filter(forum => forum.isFavorite);
    }
    
    // Apply my forums filter
    if (filters.showMyForums) {
      result = result.filter(forum => forum.author === currentUserId);
    }
    
    setFilteredForums(result);
  }, [forums, filters, currentUserId]);
  
  // Set individual filter
  const setFilter = useCallback((key: keyof ForumFilters, value: string | boolean) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  }, []);
  
  // Fetch forums data (would connect to API in real implementation)
  const fetchForums = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    
    try {
      // In a real implementation, this would be an API call
      // const response = await fetch('/api/forums');
      // const data = await response.json();
      // setForums(data);
      
      // Using sample data for now
      setForums(sampleForums);
      setIsLoading(false);
    } catch (err) {
      setError('Failed to fetch forums');
      setIsLoading(false);
    }
  }, []);
  
  // Fetch comments for a specific forum
  const fetchComments = useCallback(async (forumId: string) => {
    if (comments[forumId]) return; // Already loaded
    
    try {
      // In a real implementation, this would be an API call
      // const response = await fetch(/api/forums/${forumId}/comments);
      // const data = await response.json();
      
      // Using sample data or empty array for now
      const forumComments = sampleComments[forumId] || [];
      
      setComments(prev => ({
        ...prev,
        [forumId]: forumComments
      }));
    } catch (err) {
      console.error('Failed to fetch comments');
    }
  }, [comments]);
  
  // Toggle favorite status
  const toggleFavorite = useCallback(async (id: string) => {
    try {
      // In a real implementation, this would be an API call
      // await fetch(/api/forums/${id}/favorite, {
      //   method: 'POST',
      //   body: JSON.stringify({ isFavorite: !forums.find(f => f.id === id)?.isFavorite })
      // });
      
      // Update local state
      setForums(prev => 
        prev.map(forum => 
          forum.id === id ? { ...forum, isFavorite: !forum.isFavorite } : forum
        )
      );
    } catch (err) {
      console.error('Failed to toggle favorite');
    }
  }, [forums]);
  
  // Handle upvoting
  const handleUpvote = useCallback(async (id: string) => {
    try {
      // In a real implementation, this would be an API call
      // await fetch(/api/forums/${id}/upvote, { method: 'POST' });
      
      // Update local state
      setForums(prev => 
        prev.map(forum => 
          forum.id === id ? { ...forum, upvotes: forum.upvotes + 1 } : forum
        )
      );
    } catch (err) {
      console.error('Failed to upvote');
    }
  }, []);
  
  // Handle downvoting
  const handleDownvote = useCallback(async (id: string) => {
    try {
      // In a real implementation, this would be an API call
      // await fetch(/api/forums/${id}/downvote, { method: 'POST' });
      
      // Update local state
      setForums(prev => 
        prev.map(forum => 
          forum.id === id ? { ...forum, downvotes: forum.downvotes + 1 } : forum
        )
      );
    } catch (err) {
      console.error('Failed to downvote');
    }
  }, []);
  
  // Create new forum
  const createForum = useCallback(async (data: CreateForumData) => {
    try {
      // In a real implementation, this would be an API call with file upload
      // const formData = new FormData();
      // formData.append('title', data.title);
      // formData.append('url', data.url || '');
      // formData.append('category', data.category);
      // if (data.image) formData.append('image', data.image);
      
      // const response = await fetch('/api/forums', {
      //   method: 'POST',
      //   body: formData
      // });
      // const createdForum = await response.json();
      
      // For now, create a local forum object
      const newForum: Forum = {
        id: Date.now().toString(),
        title: data.title,
        image: data.image ? URL.createObjectURL(data.image) : '/image/pizza.jpg', // Default image
        url: data.url || 'www.example.com',
        timestamp: 'Just now',
        comments: 0,
        views: 0,
        upvotes: 0,
        downvotes: 0,
        author: currentUserId,
        category: data.category,
        isFavorite: false
      };
      
      // Update local state
      setForums(prev => [newForum, ...prev]);
      
      return newForum;
    } catch (err) {
      console.error('Failed to create forum');
      throw err;
    }
  }, [currentUserId]);
  
  // Add comment to a forum
  const addComment = useCallback(async (forumId: string, content: string) => {
    try {
      // In a real implementation, this would be an API call
      // const response = await fetch(/api/forums/${forumId}/comments, {
      //   method: 'POST',
      //   body: JSON.stringify({ content })
      // });
      // const newComment = await response.json();
      
      // Create a local comment object
      const newComment: Comment = {
        id: Date.now().toString(),
        forumId,
        userId: currentUserId,
        username: 'You', // Would come from user profile
        content,
        timestamp: 'Just now',
        replies: []
      };
      
      // Update local state
      setComments(prev => ({
        ...prev,
        [forumId]: [...(prev[forumId] || []), newComment]
      }));
      
      // Update comment count
      setForums(prev => 
        prev.map(forum => 
          forum.id === forumId ? { ...forum, comments: forum.comments + 1 } : forum
        )
      );
      
      return newComment;
    } catch (err) {
      console.error('Failed to add comment');
      throw err;
    }
  }, [currentUserId]);
  
  // Add reply to a comment
  const addReply = useCallback(async (forumId: string, commentId: string, content: string) => {
    try {
      // In a real implementation, this would be an API call
      // const response = await fetch(/api/comments/${commentId}/replies, {
      //   method: 'POST',
      //   body: JSON.stringify({ content })
      // });
      // const newReply = await response.json();
      
      // Create a local reply object
      const newReply: Reply = {
        id: `${commentId}-${Date.now()}`,  // Fixed backticks
        commentId,
        userId: currentUserId,
        username: 'You', // Would come from user profile
        content,
        timestamp: 'Just now'
      };
      
      // Update local state
      setComments(prev => {
        const forumComments = prev[forumId] || [];
        const updatedComments = forumComments.map(comment => 
          comment.id === commentId
            ? { ...comment, replies: [...comment.replies, newReply] }
            : comment
        );
        
        return {
          ...prev,
          [forumId]: updatedComments
        };
      });
      
      // Update comment count in forums
      setForums(prev => 
        prev.map(forum => 
          forum.id === forumId ? { ...forum, comments: forum.comments + 1 } : forum
        )
      );
      
      return newReply;
    } catch (err) {
      console.error('Failed to add reply');
      throw err;
    }
  }, [currentUserId]);
  
  return {
    // Data
    forums: filteredForums,
    comments,
    authors,
    categories,
    isLoading,
    error,
    activeCommentId,
    
    // Filters
    filters,
    setFilter,
    
    // Actions
    fetchForums,
    fetchComments,
    toggleFavorite,
    handleUpvote,
    handleDownvote,
    createForum,
    addComment,
    addReply,
    setActiveCommentId
  };
};

export default useForums;