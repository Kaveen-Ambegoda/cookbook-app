"use client";

import React, { useState, useEffect } from 'react';
import { Plus } from 'lucide-react';
import useForums from '../hooks/UseForums';
import SearchFilters from './SearchFilters';
import ForumPost from './ForumPost';
import CreateForumModal from './CreateForumModal';
import { CreateForumData } from '../types/index';

interface CommunityForumProps {
  userId: string;
}

const CommunityForum: React.FC<CommunityForumProps> = ({ userId = 'CurrentUser' }) => {
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  
  const {
    forums,
    comments,
    authors,
    categories,
    isLoading,
    error,
    filters,
    setFilter,
    activeCommentId,
    setActiveCommentId,
    fetchForums,
    fetchComments,
    toggleFavorite,
    handleUpvote,
    handleDownvote,
    createForum,
    addComment,
    addReply
  } = useForums({ currentUserId: userId });
  
  useEffect(() => {
    fetchForums();
    // Reset category filter to "All" to show all forums initially
    setFilter('category', 'All');
    // Make sure showMyForums is initially false
    setFilter('showMyForums', false);
  }, [fetchForums, setFilter]);
  
  useEffect(() => {
    if (activeCommentId) {
      fetchComments(activeCommentId);
    }
  }, [activeCommentId, fetchComments]);
  
  const handleToggleComments = (forumId: string) => {
    setActiveCommentId(activeCommentId === forumId ? null : forumId);
  };
  
  const handleCreateForum = async (data: CreateForumData) => {
    await createForum(data);
    setIsCreateModalOpen(false);
    // Reset category to "All" to ensure the new forum is visible
    setFilter('category', 'All');
  };

  // Handler for All Forums button
  const showAllForums = () => {
    setFilter('showMyForums', false);
    setFilter('showFavorites', false);
    setFilter('category', 'All');
  };
  
  // Handler for My Forums button
  const toggleMyForums = () => {
    setFilter('showMyForums', !filters.showMyForums);
    if (filters.showFavorites) {
      setFilter('showFavorites', false);
    }
  };
  
  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      {/* Search and Filter Section */}
      <SearchFilters
        filters={filters}
        setFilter={setFilter}
        authors={authors}
        categories={categories}
      />
      
      {/* Action Buttons */}
      <div className="flex justify-between mb-8">
        <div className="flex gap-4">
          <button 
            className={`py-2 px-4 rounded-lg ${!filters.showMyForums ? 'bg-green-600 text-white' : 'bg-green-500 text-white'}`}
            onClick={showAllForums}
          >
            All Forums
          </button>

          <button 
            className={`py-2 px-4 rounded-lg ${filters.showMyForums ? 'bg-blue-600 text-white' : 'bg-blue-500 text-white'}`}
            onClick={toggleMyForums}
          >
            My Forums
          </button>

        </div>
        <button 
          className="bg-green-500 text-white py-2 px-4 rounded-lg flex items-center gap-2"
          onClick={() => setIsCreateModalOpen(true)}
        >
          <Plus size={18} />
          Create Forum
        </button>
      </div>
      
      {/* Error Message */}
      {error && (
        <div className="bg-red-50 text-red-600 p-4 rounded-lg mb-6">
          {error}
        </div>
      )}
      
      {/* Loading State */}
      {isLoading ? (
        <div className="text-center py-10">
          <div className="inline-block animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-green-500"></div>
          <p className="mt-2 text-gray-500">Loading forums...</p>
        </div>
      ) : (
        <div className="space-y-6">
          {forums.length > 0 ? (
            forums.map(forum => (
              <ForumPost
                key={forum.id}
                forum={forum}
                onToggleFavorite={toggleFavorite}
                onUpvote={handleUpvote}
                onDownvote={handleDownvote}
                onToggleComments={handleToggleComments}
                activeCommentId={activeCommentId}
                onAddComment={addComment}
                onAddReply={addReply}
                comments={comments[forum.id] || []}
              />
            ))
          ) : (
            <div className="text-center py-10 bg-white rounded-lg shadow-sm">
              <p className="text-gray-500">
                {filters.showMyForums 
                  ? "You haven't created any forums yet." 
                  : "No forums found matching your criteria."
                }
              </p>
              <button 
                className="mt-4 bg-green-500 text-white py-2 px-4 rounded-lg"
                onClick={() => setIsCreateModalOpen(true)}
              >
                Create Your First Forum
              </button>
            </div>
          )}
        </div>
      )}
      
      {/* Create Forum Modal */}
      {isCreateModalOpen && (
        <CreateForumModal 
          onClose={() => setIsCreateModalOpen(false)} 
          onCreate={handleCreateForum}
          categories={categories.filter(cat => cat !== 'All')}
        />
      )}
    </div>
  );
};

export default CommunityForum;