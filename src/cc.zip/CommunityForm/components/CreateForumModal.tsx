"use client";

import React, { useState } from 'react';
import { X } from 'lucide-react';
import { CreateForumData } from '../types';

interface CreateForumModalProps {
  onClose: () => void;
  onCreate: (data: CreateForumData) => Promise<any>;
  categories: string[];
}

const CreateForumModal: React.FC<CreateForumModalProps> = ({
  onClose,
  onCreate,
  categories
}) => {
  const [title, setTitle] = useState('');
  const [url, setUrl] = useState('');
  const [category, setCategory] = useState(categories[0] || '');
  const [image, setImage] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  // Handle image selection
  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setImage(file);
      
      // Create preview URL
      const reader = new FileReader();
      reader.onload = (e) => {
        if (e.target && typeof e.target.result === 'string') {
          setImagePreview(e.target.result);
        }
      };
      reader.readAsDataURL(file);
    }
  };
  
  // Form submission
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!title.trim()) {
      setError('Title is required');
      return;
    }
    
    if (isSubmitting) return;
    
    try {
      setIsSubmitting(true);
      setError(null);
      
      await onCreate({
        title,
        url,
        category,
        image
      });
      
      // Close modal after successful creation
      onClose();
    } catch (err) {
      setError('Failed to create forum. Please try again.');
      setIsSubmitting(false);
    }
  };
  
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50" onClick={onClose}>
      <div className="bg-white rounded-lg w-full max-w-lg mx-4" onClick={(e) => e.stopPropagation()}>
        <div className="p-6">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-xl font-medium">Create New Forum</h3>
            <button 
              className="text-gray-400 hover:text-gray-500"
              onClick={onClose}
              aria-label="Close"
            >
              <X size={20} />
            </button>
          </div>
          
          {error && (
            <div className="bg-red-50 text-red-500 p-3 rounded mb-4">
              {error}
            </div>
          )}
          
          <form onSubmit={handleSubmit}>
            <div className="space-y-4">
              <div>
                <label htmlFor="forum-title" className="block text-sm font-medium text-gray-700 mb-1">
                  Forum Title
                </label>
                <input
                  id="forum-title"
                  type="text"
                  className="w-full border rounded-lg p-2"
                  placeholder="Enter a title for your forum"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  required
                />
              </div>
              
              <div>
                <label htmlFor="forum-url" className="block text-sm font-medium text-gray-700 mb-1">
                  Website URL (optional)
                </label>
                <input
                  id="forum-url"
                  type="text"
                  className="w-full border rounded-lg p-2"
                  placeholder="www.example.com"
                  value={url}
                  onChange={(e) => setUrl(e.target.value)}
                />
              </div>
              
              <div>
                <label htmlFor="forum-category" className="block text-sm font-medium text-gray-700 mb-1">
                  Category
                </label>
                <select
                  id="forum-category"
                  className="w-full border rounded-lg p-2"
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  required
                >
                  {categories.map(cat => (
                    <option key={cat} value={cat}>{cat}</option>
                  ))}
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Forum Image
                </label>
                <div className="flex items-center gap-4">
                  <div className="w-24 h-24 border rounded flex items-center justify-center bg-gray-50 overflow-hidden">
                    {imagePreview ? (
                      <img 
                        src={imagePreview} 
                        alt="Preview" 
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <span className="text-gray-400 text-xs text-center">No image selected</span>
                    )}
                  </div>
                  <div>
                    <input
                      type="file"
                      id="forum-image"
                      className="hidden"
                      accept="image/*"
                      onChange={handleImageChange}
                    />
                    <label 
                      htmlFor="forum-image"
                      className="bg-gray-200 hover:bg-gray-300 px-3 py-2 rounded text-sm cursor-pointer inline-block"
                    >
                      Choose Image
                    </label>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="mt-6 flex justify-end gap-3">
              <button
                type="button"
                className="px-4 py-2 border rounded-lg text-gray-700"
                onClick={onClose}
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 bg-green-500 text-white rounded-lg"
                disabled={isSubmitting || !title.trim()}
              >
                {isSubmitting ? 'Creating...' : 'Create Forum'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default CreateForumModal;